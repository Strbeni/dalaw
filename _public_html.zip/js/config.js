// Supabase Configuration
// DO NOT commit this file to Git
window.SUPABASE_URL = 'https://fgsnwktexkvhiclvxckz.supabase.co';
window.SUPABASE_ANON_KEY = 'sb_publishable_oBjpmqrzZpxo8zrCzfQkrA_D7wLigGL';
